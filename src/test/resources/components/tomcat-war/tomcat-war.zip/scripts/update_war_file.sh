#!/bin/sh
echo "Update war file to ${WAR_URL} at path ${CONTEXT_PATH}"