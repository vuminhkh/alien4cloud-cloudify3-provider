#!/bin/sh

currHostName=`hostname`

currFilename=$(basename "$0")

echo "${currHostName}:${currFilename} Tomcat url ${TOMCAT_URL}"

echo "${currHostName}:${currFilename} Tomcat port ${TOMCAT_PORT}"

echo "${currHostName}:${currFilename} Tomcat home ${TOMCAT_HOME}"

if [ -f /usr/bin/wget ]; then
	DOWNLOADER="wget"
elif [ -f /usr/bin/curl ]; then
	DOWNLOADER="curl"
fi

echo "${currHostName}:${currFilename} :DOWNLOADER ${DOWNLOADER}"

# args:
# $1 the error code of the last command (should be explicitly passed)
# $2 the message to print in case of an error
#
# an error message is printed and the script exists with the provided error code
error_exit () {
	echo "${currHostName}:${currFilename} $2 : error code: $1"
	exit $1
}

# args:
# $1 download description.
# $2 download link.
# $3 output file.
download () {
	echo "${currHostName}:${currFilename} Downloading $1 from $2 ..."
	if [ "$DOWNLOADER" = "wget" ];then
		Q_FLAG="--no-check-certificate"
		O_FLAG="-O"
		LINK_FLAG=""
	elif [ "$DOWNLOADER" = "curl" ];then
		Q_FLAG=""
		O_FLAG="-o"
		LINK_FLAG="-O"
	fi
	echo "${currHostName}:${currFilename} $DOWNLOADER $4 $Q_FLAG $O_FLAG $3 $LINK_FLAG $2"
	$DOWNLOADER $Q_FLAG $O_FLAG $3 $LINK_FLAG $2 || error_exit $? "Failed downloading $1"
}

# create tomcat home if not exist
if [ ! -d "$TOMCAT_HOME" ]; then
    mkdir -p $TOMCAT_HOME
fi

echo "${currHostName}:${currFilename} Downloading ${TOMCAT_URL} to ${destJavaArchive} ..."
download "JDK" $TOMCAT_URL $TOMCAT_HOME/tomcat_archive.tar.gz

# Install tomcat
tar xzvf $TOMCAT_HOME/tomcat_archive.tar.gz --strip 1 -C $TOMCAT_HOME
rm $TOMCAT_HOME/tomcat_archive.tar.gz

tomcatConfFolder=$TOMCAT_HOME/conf
serverXml=$tomcatConfFolder/server.xml

echo "${currHostName}:${currFilename} Configure tomcat to use port ${TOMCAT_PORT}"
sed -i -e "s/port=\"8080\"/port=\"$TOMCAT_PORT\"/g" $serverXml